# lambda 배포 테스트

* 이 디렉터리는 greengrass lambda 를 위한 테스트 디렉터리 임.

* 로컬에서 작성한 lambda를 servewrless를 이용하여 AWS에 배포 할 예정.


## 오늘 한 삽질